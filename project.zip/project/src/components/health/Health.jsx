import React from 'react';
import { Routes, Route } from 'react-router-dom';
import MenstrualTracker from './MenstrualTracker';
import MentalHealth from './MentalHealth';
import FitnessNutrition from './FitnessNutrition';
import HealthDirectory from './HealthDirectory';

function Health() {
  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Health & Wellness Hub</h1>
      <Routes>
        <Route index element={<MenstrualTracker />} />
        <Route path="mental-health" element={<MentalHealth />} />
        <Route path="fitness" element={<FitnessNutrition />} />
        <Route path="directory" element={<HealthDirectory />} />
      </Routes>
    </div>
  );
}

export default Health;