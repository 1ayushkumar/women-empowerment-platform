export default function FitnessNutrition() {
  // ... existing code
}import React from 'react';
import Card from '../shared/Card';
import { HeartIcon, ChatBubbleLeftIcon, BookOpenIcon } from '@heroicons/react/24/outline';

const resources = [
  {
    title: 'Online Counseling',
    description: 'Connect with licensed therapists for confidential support',
    icon: ChatBubbleLeftIcon,
    action: 'Book Session',
  },
  {
    title: 'Self-Help Resources',
    description: 'Access guides and tools for managing stress and anxiety',
    icon: BookOpenIcon,
    action: 'View Resources',
  },
  {
    title: 'Support Groups',
    description: 'Join virtual support groups led by mental health professionals',
    icon: HeartIcon,
    action: 'Join Group',
  },
];

function MentalHealth() {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-semibold mb-6">Mental Health Support</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {resources.map((resource, index) => (
          <Card key={index}>
            <resource.icon className="h-8 w-8 text-purple-600 mb-4" />
            <h3 className="text-xl font-semibold mb-2">{resource.title}</h3>
            <p className="text-gray-600 mb-4">{resource.description}</p>
            <button className="bg-purple-600 text-white px-4 py-2 rounded hover:bg-purple-700">
              {resource.action}
            </button>
          </Card>
        ))}
      </div>
    </div>
  );
}