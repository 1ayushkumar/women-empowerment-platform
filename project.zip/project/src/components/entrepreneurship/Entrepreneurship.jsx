import React from 'react';
import { Link } from 'react-router-dom';
import BusinessTools from "./BusinessTools";
import Funding from "./Funding";
import Marketplace from "./Marketplace";
import NetworkingEvents from "./NetworkingEvents";

function Entrepreneurship() {
  const sections = [
    {
      title: 'Business Tools',
      description: 'Access essential tools and resources to start and grow your business',
      icon: (
        <svg className="w-12 h-12 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
        </svg>
      ),
      path: '#business-tools',
      image: 'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=500&auto=format'
    },
    {
      title: 'Funding Opportunities',
      description: 'Discover grants, loans, and investment opportunities for women entrepreneurs',
      icon: (
        <svg className="w-12 h-12 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
      ),
      path: '#funding',
      image: 'https://images.unsplash.com/photo-1553729459-efe14ef6055d?w=500&auto=format'
    },
    {
      title: 'Marketplace',
      description: 'Connect with customers and sell your products in our women-focused marketplace',
      icon: (
        <svg className="w-12 h-12 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
        </svg>
      ),
      path: '#marketplace',
      image: 'https://images.unsplash.com/photo-1472851294608-062f824d29cc?w=500&auto=format'
    },
    {
      title: 'Networking Events',
      description: 'Join events and connect with other women entrepreneurs',
      icon: (
        <svg className="w-12 h-12 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
        </svg>
      ),
      path: '#networking',
      image: 'https://images.unsplash.com/photo-1528605248644-14dd04022da1?w=500&auto=format'
    }
  ];

  const successStories = [
    {
      name: 'Sarah Chen',
      business: 'EcoStyle Fashion',
      image: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=300&h=300&fit=crop',
      quote: 'The funding and mentorship I received helped me turn my sustainable fashion idea into a thriving business.',
      businessImage: 'https://images.unsplash.com/photo-1581375074612-d1fd0e661aeb?w=500&auto=format'
    },
    {
      name: 'Maria Rodriguez',
      business: 'Tech Solutions Inc',
      image: 'https://images.unsplash.com/photo-1580894732444-8ecded7900cd?w=300&h=300&fit=crop',
      quote: 'The business tools and networking events were instrumental in scaling my tech startup.',
      businessImage: 'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?w=500&auto=format'
    },
    {
      name: 'Lisa Wong',
      business: 'Organic Beauty Co',
      image: 'https://images.unsplash.com/photo-1594744803329-e58b31de8bf5?w=300&h=300&fit=crop',
      quote: 'The marketplace platform helped me reach customers globally and grow my organic beauty brand.',
      businessImage: 'https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=500&auto=format'
    },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-purple-600 to-pink-500 rounded-3xl p-8 md:p-12 mb-12 text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="relative z-10 max-w-3xl">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Empower Your Entrepreneurial Journey
          </h1>
          <p className="text-lg md:text-xl opacity-90 mb-8">
            Access resources, funding, and support designed specifically for women entrepreneurs.
          </p>
          <Link
            to="#get-started"
            className="inline-block bg-white text-purple-600 px-6 py-3 rounded-lg font-semibold hover:bg-purple-50 transition-colors"
          >
            Get Started
          </Link>
        </div>
      </div>

      {/* Quick Links */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
        {sections.map((section, index) => (
          <Link
            key={index}
            to={section.path}
            className="group bg-white rounded-xl overflow-hidden shadow-lg hover:shadow-xl transition-all"
          >
            <div className="h-48 overflow-hidden">
              <img 
                src={section.image} 
                alt={section.title}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
              />
            </div>
            <div className="p-6">
              <div className="mb-4">{section.icon}</div>
              <h3 className="text-xl font-semibold mb-2">{section.title}</h3>
              <p className="text-gray-600">{section.description}</p>
            </div>
          </Link>
        ))}
      </div>

      {/* Main Content Sections */}
      <div className="space-y-12">
        <section id="business-tools" className="scroll-mt-16">
          <h2 className="text-3xl font-bold mb-6">Business Tools</h2>
          <BusinessTools />
        </section>

        <section id="funding" className="scroll-mt-16">
          <h2 className="text-3xl font-bold mb-6">Funding Opportunities</h2>
          <Funding />
        </section>

        <section id="marketplace" className="scroll-mt-16">
          <h2 className="text-3xl font-bold mb-6">Marketplace</h2>
          <Marketplace />
        </section>

        <section id="networking" className="scroll-mt-16">
          <h2 className="text-3xl font-bold mb-6">Networking Events</h2>
          <NetworkingEvents />
        </section>
      </div>

      {/* Success Stories */}
      <section className="mt-16 bg-purple-50 rounded-3xl p-8">
        <h2 className="text-3xl font-bold mb-8 text-center">Success Stories</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {successStories.map((story, index) => (
            <div key={index} className="bg-white rounded-xl overflow-hidden shadow-md hover:shadow-lg transition-shadow">
              <div className="h-48 overflow-hidden">
                <img
                  src={story.businessImage}
                  alt={`${story.business} business`}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-6">
                <div className="flex items-center mb-4">
                  <img
                    src={story.image}
                    alt={story.name}
                    className="w-16 h-16 rounded-full mr-4 object-cover"
                  />
                  <div>
                    <h3 className="text-xl font-semibold">{story.name}</h3>
                    <p className="text-purple-600">{story.business}</p>
                  </div>
                </div>
                <p className="text-gray-600 italic">&quot;{story.quote}&quot;</p>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

export default Entrepreneurship;