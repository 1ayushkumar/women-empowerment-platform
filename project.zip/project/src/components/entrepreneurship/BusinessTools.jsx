import React from 'react';
import Card from '../shared/Card';

const tools = [
  {
    name: 'Business Plan Generator',
    description: 'Create professional business plans with our easy-to-use template.',
    features: ['Custom templates', 'Financial projections', 'Market analysis'],
  },
  {
    name: 'Financial Calculator',
    description: 'Calculate startup costs, revenue projections, and break-even analysis.',
    features: ['Cost analysis', 'Revenue forecasting', 'Break-even calculator'],
  },
  {
    name: 'Legal Document Templates',
    description: 'Access essential legal documents for your business.',
    features: ['Contracts', 'Agreements', 'Registration forms'],
  },
];

function BusinessTools() {
  return (
    <div className="space-y-8">
      <h2 className="text-2xl font-semibold mb-6">Business Tools</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {tools.map((tool, index) => (
          <Card key={index}>
            <h3 className="text-xl font-semibold mb-2">{tool.name}</h3>
            <p className="text-gray-600 mb-4">{tool.description}</p>
            <div className="space-y-2">
              <h4 className="font-medium">Features:</h4>
              <ul className="list-disc list-inside text-gray-600">
                {tool.features.map((feature, idx) => (
                  <li key={idx}>{feature}</li>
                ))}
              </ul>
            </div>
            <button className="mt-4 bg-purple-600 text-white px-4 py-2 rounded hover:bg-purple-700">
              Access Tool
            </button>
          </Card>
        ))}
      </div>
    </div>
  );
}

export default BusinessTools;
