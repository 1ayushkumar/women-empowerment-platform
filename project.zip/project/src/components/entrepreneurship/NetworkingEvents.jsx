import React, { useState } from 'react';
import Card from '../shared/Card';

const upcomingEvents = [
  {
    id: 1,
    title: 'Women in Business Summit',
    date: '2024-01-15',
    time: '09:00 AM - 05:00 PM',
    location: 'Virtual Event',
    type: 'Conference',
    price: 149.99,
    description: 'Annual summit featuring successful women entrepreneurs and business leaders sharing their experiences and insights.',
    speakers: [
      'Sarah Chen - Venture Capitalist',
      'Maria Rodriguez - Tech CEO',
      'Lisa Wong - Marketing Expert',
    ],
  },
  {
    id: 2,
    title: 'Networking Breakfast',
    date: '2024-01-20',
    time: '08:00 AM - 10:00 AM',
    location: 'Downtown Business Center',
    type: 'In-Person',
    price: 29.99,
    description: 'Monthly networking breakfast for women entrepreneurs to connect and share opportunities.',
    speakers: [],
  },
  {
    id: 3,
    title: 'Pitch Perfect Workshop',
    date: '2024-01-25',
    time: '02:00 PM - 04:00 PM',
    location: 'Virtual Event',
    type: 'Workshop',
    price: 79.99,
    description: 'Interactive workshop on perfecting your business pitch with live feedback sessions.',
    speakers: [
      'Emily Chang - Pitch Coach',
      'Jessica Lee - Startup Advisor',
    ],
  },
];

const eventTypes = ['All', 'Conference', 'Workshop', 'Networking', 'In-Person', 'Virtual'];

function NetworkingEvents() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState('All');
  const [events] = useState(upcomingEvents);

  const filteredEvents = events.filter(event => {
    const matchesSearch = event.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         event.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = selectedType === 'All' || event.type === selectedType;
    return matchesSearch && matchesType;
  });

  return (
    <div className="space-y-8">
      <h2 className="text-2xl font-semibold mb-6">Networking Events</h2>

      <section className="mb-8">
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="flex-1">
            <input
              type="text"
              placeholder="Search events..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full p-2 border rounded"
            />
          </div>
          <div className="w-full md:w-48">
            <select
              value={selectedType}
              onChange={(e) => setSelectedType(e.target.value)}
              className="w-full p-2 border rounded"
            >
              {eventTypes.map(type => (
                <option key={type} value={type}>{type}</option>
              ))}
            </select>
          </div>
          <button className="bg-purple-600 text-white px-6 py-2 rounded hover:bg-purple-700">
            Host Event
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredEvents.map(event => (
            <Card key={event.id}>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="text-lg font-semibold">{event.title}</h3>
                    <span className="bg-purple-100 text-purple-800 text-sm px-2 py-1 rounded">
                      {event.type}
                    </span>
                  </div>
                  <div className="text-sm text-gray-600 space-y-1">
                    <p>{event.date} | {event.time}</p>
                    <p>{event.location}</p>
                  </div>
                </div>

                <p className="text-gray-600">{event.description}</p>

                {event.speakers.length > 0 && (
                  <div>
                    <h4 className="font-medium mb-2">Featured Speakers:</h4>
                    <ul className="text-sm text-gray-600 space-y-1">
                      {event.speakers.map((speaker, idx) => (
                        <li key={idx}>{speaker}</li>
                      ))}
                    </ul>
                  </div>
                )}

                <div className="flex justify-between items-center">
                  <span className="text-lg font-medium text-purple-600">
                    ${event.price}
                  </span>
                  <button className="bg-purple-600 text-white px-4 py-2 rounded hover:bg-purple-700">
                    Register Now
                  </button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </section>

      <section>
        <h3 className="text-xl font-semibold mb-4">Host an Event</h3>
        <Card>
          <form className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Event Title
                </label>
                <input
                  type="text"
                  className="w-full p-2 border rounded"
                  placeholder="Enter event title"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Event Type
                </label>
                <select className="w-full p-2 border rounded">
                  {eventTypes.slice(1).map(type => (
                    <option key={type} value={type}>{type}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Date
                </label>
                <input
                  type="date"
                  className="w-full p-2 border rounded"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Time
                </label>
                <input
                  type="time"
                  className="w-full p-2 border rounded"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Location
                </label>
                <input
                  type="text"
                  className="w-full p-2 border rounded"
                  placeholder="Enter location or virtual link"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Price
                </label>
                <input
                  type="number"
                  className="w-full p-2 border rounded"
                  placeholder="Enter ticket price"
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Event Description
              </label>
              <textarea
                className="w-full p-2 border rounded h-24"
                placeholder="Describe your event..."
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Featured Speakers
              </label>
              <textarea
                className="w-full p-2 border rounded h-24"
                placeholder="Enter speaker names and titles (one per line)..."
              />
            </div>
            <button
              type="submit"
              className="w-full bg-purple-600 text-white px-4 py-2 rounded hover:bg-purple-700"
            >
              Create Event
            </button>
          </form>
        </Card>
      </section>
    </div>
  );
}

export default NetworkingEvents;
