import React, { useState } from 'react';
import Card from '../shared/Card';

const initialProducts = [
  {
    id: 1,
    name: 'Handcrafted Jewelry',
    seller: 'Artisan Creations',
    price: 45.99,
    category: 'Crafts',
    description: 'Unique handmade jewelry pieces using sustainable materials.',
    image: 'https://placehold.co/300x200',
  },
  {
    id: 2,
    name: 'Organic Skincare Set',
    seller: 'Natural Beauty Co',
    price: 89.99,
    category: 'Beauty',
    description: 'All-natural skincare products made with organic ingredients.',
    image: 'https://placehold.co/300x200',
  },
  {
    id: 3,
    name: 'Digital Marketing Course',
    seller: 'Business Growth Academy',
    price: 199.99,
    category: 'Education',
    description: 'Comprehensive course on digital marketing strategies.',
    image: 'https://placehold.co/300x200',
  },
];

const categories = ['All', 'Crafts', 'Beauty', 'Education', 'Food', 'Services'];

function Marketplace() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [products] = useState(initialProducts);

  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         product.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || product.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="space-y-8">
      <h2 className="text-2xl font-semibold mb-6">Women's Marketplace</h2>

      <section className="mb-8">
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="flex-1">
            <input
              type="text"
              placeholder="Search products..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full p-2 border rounded"
            />
          </div>
          <div className="w-full md:w-48">
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full p-2 border rounded"
            >
              {categories.map(category => (
                <option key={category} value={category}>{category}</option>
              ))}
            </select>
          </div>
          <button className="bg-purple-600 text-white px-6 py-2 rounded hover:bg-purple-700">
            List Your Product
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProducts.map(product => (
            <Card key={product.id}>
              <img
                src={product.image}
                alt={product.name}
                className="w-full h-48 object-cover rounded-lg mb-4"
              />
              <div className="space-y-2">
                <div className="flex justify-between items-start">
                  <h3 className="text-lg font-semibold">{product.name}</h3>
                  <span className="text-lg font-medium text-purple-600">
                    ${product.price}
                  </span>
                </div>
                <p className="text-sm text-gray-500">By {product.seller}</p>
                <p className="text-gray-600">{product.description}</p>
                <div className="flex justify-between items-center mt-4">
                  <span className="bg-purple-100 text-purple-800 text-sm px-2 py-1 rounded">
                    {product.category}
                  </span>
                  <button className="bg-purple-600 text-white px-4 py-2 rounded hover:bg-purple-700">
                    View Details
                  </button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </section>

      <section>
        <h3 className="text-xl font-semibold mb-4">List Your Product</h3>
        <Card>
          <form className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Product Name
                </label>
                <input
                  type="text"
                  className="w-full p-2 border rounded"
                  placeholder="Enter product name"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Category
                </label>
                <select className="w-full p-2 border rounded">
                  {categories.slice(1).map(category => (
                    <option key={category} value={category}>{category}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Price
                </label>
                <input
                  type="number"
                  className="w-full p-2 border rounded"
                  placeholder="Enter price"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Product Image
                </label>
                <input
                  type="file"
                  className="w-full p-2 border rounded"
                  accept="image/*"
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Description
              </label>
              <textarea
                className="w-full p-2 border rounded h-24"
                placeholder="Describe your product..."
              />
            </div>
            <button
              type="submit"
              className="w-full bg-purple-600 text-white px-4 py-2 rounded hover:bg-purple-700"
            >
              List Product
            </button>
          </form>
        </Card>
      </section>
    </div>
  );
}

export default Marketplace;
