import React from 'react';
import Card from '../shared/Card';

const fundingOpportunities = [
  {
    title: 'Women Entrepreneurs Grant',
    amount: '$25,000',
    deadline: '2024-02-28',
    eligibility: [
      'Women-owned business',
      'In operation for at least 1 year',
      'Revenue under $500,000',
    ],
    type: 'Grant',
  },
  {
    title: 'Tech Startup Seed Fund',
    amount: '$50,000',
    deadline: '2024-03-15',
    eligibility: [
      'Technology-focused startup',
      'MVP ready',
      'Clear growth strategy',
    ],
    type: 'Seed Investment',
  },
  {
    title: 'Small Business Loan Program',
    amount: 'Up to $100,000',
    deadline: 'Rolling',
    eligibility: [
      'Credit score above 650',
      'Business plan required',
      '2+ years in business',
    ],
    type: 'Loan',
  },
];

const resources = [
  {
    title: 'Pitch Deck Template',
    description: 'Professional template for creating compelling investor presentations.',
    type: 'Template',
  },
  {
    title: 'Financial Projections Tool',
    description: 'Excel-based tool for creating 3-5 year financial projections.',
    type: 'Tool',
  },
];

function Funding() {
  return (
    <div className="space-y-8">
      <h2 className="text-2xl font-semibold mb-6">Funding Opportunities</h2>

      <section className="mb-8">
        <h3 className="text-xl font-semibold mb-4">Available Funding</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {fundingOpportunities.map((opportunity, index) => (
            <Card key={index}>
              <div className="flex justify-between items-start mb-4">
                <h4 className="text-lg font-semibold">{opportunity.title}</h4>
                <span className="bg-purple-100 text-purple-800 text-sm px-2 py-1 rounded">
                  {opportunity.type}
                </span>
              </div>
              <div className="space-y-3">
                <p className="text-xl font-medium text-purple-600">{opportunity.amount}</p>
                <p><span className="font-medium">Deadline:</span> {opportunity.deadline}</p>
                <div>
                  <h5 className="font-medium mb-2">Eligibility:</h5>
                  <ul className="list-disc list-inside text-gray-600">
                    {opportunity.eligibility.map((criteria, idx) => (
                      <li key={idx}>{criteria}</li>
                    ))}
                  </ul>
                </div>
              </div>
              <button className="mt-4 bg-purple-600 text-white px-4 py-2 rounded hover:bg-purple-700">
                Apply Now
              </button>
            </Card>
          ))}
        </div>
      </section>

      <section>
        <h3 className="text-xl font-semibold mb-4">Funding Resources</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {resources.map((resource, index) => (
            <Card key={index}>
              <h4 className="text-lg font-semibold mb-2">{resource.title}</h4>
              <p className="text-gray-600 mb-2">{resource.description}</p>
              <span className="text-sm text-purple-600">{resource.type}</span>
              <button className="mt-4 w-full bg-purple-600 text-white px-4 py-2 rounded hover:bg-purple-700">
                Download
              </button>
            </Card>
          ))}
        </div>
      </section>

      <section>
        <h3 className="text-xl font-semibold mb-4">Funding Application Support</h3>
        <Card>
          <form className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Business Name
              </label>
              <input
                type="text"
                className="w-full p-2 border rounded"
                placeholder="Enter your business name"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Funding Type Interested In
              </label>
              <select className="w-full p-2 border rounded">
                <option value="">Select funding type</option>
                <option value="grant">Grant</option>
                <option value="loan">Loan</option>
                <option value="investment">Investment</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Amount Needed
              </label>
              <input
                type="number"
                className="w-full p-2 border rounded"
                placeholder="Enter amount needed"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Business Description
              </label>
              <textarea
                className="w-full p-2 border rounded h-24"
                placeholder="Briefly describe your business and funding needs..."
              />
            </div>
            <button
              type="submit"
              className="w-full bg-purple-600 text-white px-4 py-2 rounded hover:bg-purple-700"
            >
              Request Support
            </button>
          </form>
        </Card>
      </section>
    </div>
  );
}

export default Funding;
