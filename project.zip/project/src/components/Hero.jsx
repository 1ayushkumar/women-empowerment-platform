import React from 'react';

function Hero() {
  return (
    <div className="bg-gradient-to-r from-purple-600 to-pink-500 text-white">
      <div className="max-w-7xl mx-auto px-4 py-20">
        <div className="text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6">
            Empowering Women Through Technology
          </h1>
          <p className="text-xl mb-8">
            Join our platform to access education, opportunities, and support for your journey
          </p>
          <div className="space-x-4">
            <button className="bg-white text-purple-600 px-8 py-3 rounded-full font-semibold hover:bg-purple-100">
              Get Started
            </button>
            <button className="border-2 border-white px-8 py-3 rounded-full font-semibold hover:bg-white hover:text-purple-600">
              Learn More
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Hero;