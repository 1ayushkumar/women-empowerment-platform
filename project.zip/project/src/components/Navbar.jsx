import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import useAuthStore from '../store/authStore';

function Navbar() {
  const isAuthenticated = useAuthStore((state) => state.isAuthenticated);
  const user = useAuthStore((state) => state.user);
  const logout = useAuthStore((state) => state.logout);
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <nav className="bg-purple-700 text-white shadow-lg">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="text-xl font-bold">
              Women's Empowerment
            </Link>
          </div>
          <div className="flex items-center space-x-4">
            {isAuthenticated ? (
              <>
                <Link to="/home" className="hover:text-purple-200">
                  Home
                </Link>
                <Link to="/education" className="hover:text-purple-200">
                  Education
                </Link>
                <Link to="/entrepreneurship" className="hover:text-purple-200">
                  Entrepreneurship
                </Link>
                <Link to="/employment" className="hover:text-purple-200">
                  Employment
                </Link>
                <Link to="/health" className="hover:text-purple-200">
                  Health
                </Link>
                <Link to="/safety" className="hover:text-purple-200">
                  Safety
                </Link>
                <span className="text-sm">Welcome, {user?.email}</span>
                <button
                  onClick={handleLogout}
                  className="bg-white text-purple-700 px-4 py-2 rounded-md hover:bg-purple-100"
                >
                  Logout
                </button>
              </>
            ) : (
              <>
                <Link
                  to="/login"
                  className="bg-white text-purple-700 px-4 py-2 rounded-md hover:bg-purple-100"
                >
                  Login
                </Link>
                <Link
                  to="/register"
                  className="bg-purple-600 text-white px-4 py-2 rounded-md hover:bg-purple-500"
                >
                  Register
                </Link>
              </>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;