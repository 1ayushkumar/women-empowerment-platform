import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Courses from './Courses';
import Mentorship from './Mentorship';
import Scholarships from './Scholarships';
import DiscussionForum from './DiscussionForum';

function Education() {
  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Education Hub</h1>
      <Routes>
        <Route index element={<Courses />} />
        <Route path="mentorship" element={<Mentorship />} />
        <Route path="scholarships" element={<Scholarships />} />
        <Route path="forum" element={<DiscussionForum />} />
      </Routes>
    </div>
  );
}

export default Education;