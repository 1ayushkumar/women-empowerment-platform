import React from 'react';
import Card from '../shared/Card';

const mentors = [
  {
    name: 'Sarah Johnson',
    expertise: 'Business Development',
    experience: '15+ years',
    availability: 'Weekdays',
  },
  {
    name: 'Dr. Emily Chen',
    expertise: 'Healthcare & Research',
    experience: '12+ years',
    availability: 'Weekends',
  },
  {
    name: 'Maria Rodriguez',
    expertise: 'Technology & Innovation',
    experience: '10+ years',
    availability: 'Flexible',
  },
];

function Mentorship() {
  return (
    <div className="space-y-8">
      <h2 className="text-2xl font-semibold mb-6">Find a Mentor</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {mentors.map((mentor, index) => (
          <Card key={index}>
            <h3 className="text-xl font-semibold mb-2">{mentor.name}</h3>
            <div className="space-y-2 text-gray-600">
              <p><span className="font-medium">Expertise:</span> {mentor.expertise}</p>
              <p><span className="font-medium">Experience:</span> {mentor.experience}</p>
              <p><span className="font-medium">Availability:</span> {mentor.availability}</p>
            </div>
            <button className="mt-4 bg-purple-600 text-white px-4 py-2 rounded hover:bg-purple-700">
              Connect
            </button>
          </Card>
        ))}
      </div>
    </div>
  );
}

export default Mentorship;
