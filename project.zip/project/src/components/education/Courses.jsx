import React, { useState } from 'react';
import CourseCard from './CourseCard';

const courses = [
  // STEM Courses
  {
    id: 1,
    title: 'Introduction to Web Development',
    category: 'STEM',
    type: 'Free',
    duration: '8 weeks',
    instructor: 'Sarah Johnson',
    rating: 4.8,
    students: 1200,
    description: 'Learn the fundamentals of web development including HTML, CSS, and JavaScript.',
    image: 'https://images.unsplash.com/photo-1587620962725-abab7fe55159?w=600&h=400&fit=crop',
  },
  {
    id: 2,
    title: 'Data Science Fundamentals',
    category: 'STEM',
    type: 'Paid',
    price: 49.99,
    duration: '10 weeks',
    instructor: 'Emily Chen',
    rating: 4.9,
    students: 850,
    description: 'Master the basics of data analysis, Python programming, and statistical methods.',
    image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=600&h=400&fit=crop',
  },
  {
    id: 3,
    title: 'Mobile App Development',
    category: 'STEM',
    type: 'Paid',
    price: 59.99,
    duration: '12 weeks',
    instructor: 'Maria Garcia',
    rating: 4.7,
    students: 650,
    description: 'Create iOS and Android apps using React Native and modern development practices.',
    image: 'https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?w=600&h=400&fit=crop',
  },

  // Business Courses
  {
    id: 4,
    title: 'Business Plan Writing',
    category: 'Business',
    type: 'Free',
    duration: '4 weeks',
    instructor: 'Lisa Wong',
    rating: 4.6,
    students: 2100,
    description: 'Learn how to create compelling business plans that attract investors.',
    image: 'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=600&h=400&fit=crop',
  },
  {
    id: 5,
    title: 'Financial Management',
    category: 'Business',
    type: 'Paid',
    price: 39.99,
    duration: '6 weeks',
    instructor: 'Rachel Thompson',
    rating: 4.8,
    students: 1500,
    description: 'Master financial planning, budgeting, and investment strategies for your business.',
    image: 'https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?w=600&h=400&fit=crop',
  },
  {
    id: 6,
    title: 'Leadership & Management',
    category: 'Business',
    type: 'Paid',
    price: 44.99,
    duration: '8 weeks',
    instructor: 'Michelle Parker',
    rating: 4.9,
    students: 980,
    description: 'Develop essential leadership skills and learn effective team management strategies.',
    image: 'https://images.unsplash.com/photo-1552664730-d307ca884978?w=600&h=400&fit=crop',
  },

  // Digital Marketing Courses
  {
    id: 7,
    title: 'Digital Marketing Fundamentals',
    category: 'Digital Marketing',
    type: 'Free',
    duration: '6 weeks',
    instructor: 'Jessica Lee',
    rating: 4.7,
    students: 3200,
    description: 'Learn the basics of digital marketing, including SEO, social media, and content marketing.',
    image: 'https://images.unsplash.com/photo-1432888622747-4eb9a8efeb07?w=600&h=400&fit=crop',
  },
  {
    id: 8,
    title: 'Social Media Marketing',
    category: 'Digital Marketing',
    type: 'Paid',
    price: 34.99,
    duration: '5 weeks',
    instructor: 'Amanda Wilson',
    rating: 4.8,
    students: 2800,
    description: 'Master social media marketing strategies for multiple platforms.',
    image: 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=600&h=400&fit=crop',
  },
  {
    id: 9,
    title: 'Content Marketing Strategy',
    category: 'Digital Marketing',
    type: 'Paid',
    price: 39.99,
    duration: '7 weeks',
    instructor: 'Sophie Brown',
    rating: 4.6,
    students: 1900,
    description: 'Create effective content marketing strategies and compelling content.',
    image: 'https://images.unsplash.com/photo-1542435503-956c469947f6?w=600&h=400&fit=crop',
  },
];

function Courses() {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedType, setSelectedType] = useState('All');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredCourses = courses.filter(course => {
    const matchesCategory = selectedCategory === 'All' || course.category === selectedCategory;
    const matchesType = selectedType === 'All' || course.type === selectedType;
    const matchesSearch = course.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         course.description.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesType && matchesSearch;
  });

  return (
    <div className="space-y-8">
      <div className="bg-gradient-to-r from-purple-600 to-pink-500 text-white p-8 rounded-lg">
        <h1 className="text-3xl font-bold mb-4">Empower Your Future with Our Courses</h1>
        <p className="text-lg opacity-90">Discover courses designed to help you succeed in tech, business, and digital marketing.</p>
      </div>

      <div className="flex flex-col md:flex-row gap-4 items-center">
        <div className="flex-1">
          <input
            type="text"
            placeholder="Search courses..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
          />
        </div>
        <div className="flex gap-4">
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="p-3 border rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
          >
            <option value="All">All Categories</option>
            <option value="STEM">STEM</option>
            <option value="Business">Business</option>
            <option value="Digital Marketing">Digital Marketing</option>
          </select>
          <select
            value={selectedType}
            onChange={(e) => setSelectedType(e.target.value)}
            className="p-3 border rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
          >
            <option value="All">All Types</option>
            <option value="Free">Free</option>
            <option value="Paid">Paid</option>
          </select>
        </div>
      </div>

      {selectedCategory !== 'All' && (
        <div className="bg-purple-50 p-6 rounded-lg">
          <h2 className="text-xl font-semibold mb-2">{selectedCategory} Courses</h2>
          <p className="text-gray-600">
            {selectedCategory === 'STEM' && 'Explore technology and engineering courses designed for women in STEM.'}
            {selectedCategory === 'Business' && 'Master business skills with our comprehensive business courses.'}
            {selectedCategory === 'Digital Marketing' && 'Learn modern digital marketing strategies and techniques.'}
          </p>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredCourses.map(course => (
          <CourseCard key={course.id} course={course} />
        ))}
      </div>

      {filteredCourses.length === 0 && (
        <div className="text-center py-12">
          <h3 className="text-xl font-medium text-gray-900">No courses found</h3>
          <p className="mt-2 text-gray-500">Try adjusting your search or filters</p>
        </div>
      )}
    </div>
  );
}

export default Courses;