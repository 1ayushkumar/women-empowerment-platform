import React from 'react';
import Card from '../shared/Card';

const jobs = [
  {
    title: 'Software Developer',
    company: 'TechCorp',
    location: 'Remote',
    type: 'Full-time',
    description: 'Looking for a skilled software developer with experience in React and Node.js.',
  },
  {
    title: 'Project Manager',
    company: 'InnovateHub',
    location: 'Hybrid',
    type: 'Full-time',
    description: 'Seeking an experienced project manager to lead our technology initiatives.',
  },
  {
    title: 'Digital Marketing Specialist',
    company: 'GrowthCo',
    location: 'On-site',
    type: 'Part-time',
    description: 'Join our marketing team to drive digital growth and engagement.',
  },
];

function JobPortal() {
  return (
    <div className="space-y-8">
      <h2 className="text-2xl font-semibold mb-6">Job Opportunities</h2>
      <div className="space-y-6">
        {jobs.map((job, index) => (
          <Card key={index}>
            <h3 className="text-xl font-semibold mb-2">{job.title}</h3>
            <div className="space-y-2 text-gray-600">
              <p><span className="font-medium">Company:</span> {job.company}</p>
              <p><span className="font-medium">Location:</span> {job.location}</p>
              <p><span className="font-medium">Type:</span> {job.type}</p>
              <p className="mt-2">{job.description}</p>
            </div>
            <button className="mt-4 bg-purple-600 text-white px-4 py-2 rounded hover:bg-purple-700">
              Apply Now
            </button>
          </Card>
        ))}
      </div>
    </div>
  );
}

export default JobPortal;
