import React, { useState, useEffect } from 'react';
import '../../styles/animations.css';

function CareerGuidance() {
  const [activeTab, setActiveTab] = useState('path-planning');
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  const resources = {
    'path-planning': {
      title: 'Career Path Planning',
      content: [
        {
          title: 'Industry Analysis',
          description: 'Explore growing industries and future job prospects',
          image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=500&h=300&fit=crop',
          tools: ['Industry Reports', 'Market Trends', 'Growth Forecasts']
        },
        {
          title: 'Skill Assessment',
          description: 'Evaluate your current skills and identify areas for growth',
          image: 'https://images.unsplash.com/photo-1434030216411-0b793f4b4173?w=500&h=300&fit=crop',
          tools: ['Skill Matrix', 'Personality Tests', 'Strength Finder']
        },
        {
          title: 'Goal Setting',
          description: 'Set SMART career goals and create action plans',
          image: 'https://images.unsplash.com/photo-1553034545-32d4cd2168f1?w=500&h=300&fit=crop',
          tools: ['Goal Templates', 'Timeline Planner', 'Progress Tracker']
        }
      ]
    },
    'interview-prep': {
      title: 'Interview Preparation',
      content: [
        {
          title: 'Common Questions',
          description: 'Practice with frequently asked interview questions',
          image: 'https://images.unsplash.com/photo-1507537297725-24a1c029d3ca?w=500&h=300&fit=crop',
          tools: ['Question Bank', 'Response Templates', 'Mock Interview AI']
        },
        {
          title: 'Technical Interviews',
          description: 'Prepare for role-specific technical assessments',
          image: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=500&h=300&fit=crop',
          tools: ['Coding Challenges', 'System Design', 'Technical Q&A']
        },
        {
          title: 'Behavioral Questions',
          description: 'Master the STAR method for behavioral questions',
          image: 'https://images.unsplash.com/photo-1521791136064-7986c2920216?w=500&h=300&fit=crop',
          tools: ['STAR Framework', 'Situation Examples', 'Response Builder']
        }
      ]
    },
    'resume-writing': {
      title: 'Resume Writing Workshop',
      content: [
        {
          title: 'Resume Templates',
          description: 'Choose from professionally designed templates',
          image: 'https://images.unsplash.com/photo-1586281380349-632531db7ed4?w=500&h=300&fit=crop',
          tools: ['ATS-Friendly Templates', 'Industry-Specific Formats', 'Design Tools']
        },
        {
          title: 'Content Writing',
          description: 'Write compelling achievements and descriptions',
          image: 'https://images.unsplash.com/photo-1455390582262-044cdead277a?w=500&h=300&fit=crop',
          tools: ['Action Verbs List', 'Achievement Calculator', 'Grammar Checker']
        },
        {
          title: 'Optimization Tips',
          description: 'Optimize your resume for ATS and human readers',
          image: 'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=500&h=300&fit=crop',
          tools: ['Keyword Optimizer', 'ATS Checker', 'Format Validator']
        }
      ]
    }
  };

  return (
    <div className={`max-w-7xl mx-auto px-4 py-8 ${isVisible ? 'fade-in' : ''}`}>
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-purple-600 to-pink-500 rounded-3xl p-8 md:p-12 mb-12 text-white slide-in">
        <div className="max-w-3xl">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Level Up Your Career
          </h1>
          <p className="text-lg md:text-xl opacity-90 mb-8">
            Access expert resources and tools to accelerate your career growth.
          </p>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex flex-wrap gap-4 mb-8 stagger-animation">
        {Object.keys(resources).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-6 py-3 rounded-lg font-semibold transition-all hover-lift ${
              activeTab === tab
                ? 'bg-purple-600 text-white'
                : 'bg-white text-purple-600 hover:bg-purple-50'
            }`}
          >
            {resources[tab].title}
          </button>
        ))}
      </div>

      {/* Content Section */}
      <div className="space-y-12">
        {resources[activeTab].content.map((item, index) => (
          <div
            key={index}
            className="bg-white rounded-xl overflow-hidden shadow-lg hover-glow stagger-animation"
          >
            <div className="md:flex">
              <div className="md:w-1/3">
                <img
                  src={item.image}
                  alt={item.title}
                  className="w-full h-64 object-cover"
                />
              </div>
              <div className="md:w-2/3 p-6">
                <h3 className="text-2xl font-bold mb-4">{item.title}</h3>
                <p className="text-gray-600 mb-6">{item.description}</p>
                <div className="space-y-4">
                  <h4 className="font-semibold text-purple-600">Available Tools:</h4>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {item.tools.map((tool, toolIndex) => (
                      <div
                        key={toolIndex}
                        className="bg-purple-50 rounded-lg p-3 text-center hover-scale"
                      >
                        {tool}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Interactive Features */}
      <div className="mt-16 grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-white rounded-xl p-6 shadow-lg hover-lift">
          <h3 className="text-2xl font-bold mb-6">Progress Tracker</h3>
          <div className="space-y-4">
            {['Research', 'Planning', 'Preparation', 'Practice'].map((step, index) => (
              <div key={index}>
                <div className="flex justify-between mb-2">
                  <span>{step}</span>
                  <span>{25 * (index + 1)}%</span>
                </div>
                <div className="bg-purple-100 rounded-full h-2">
                  <div
                    className="bg-purple-600 rounded-full h-2 progress-bar animate"
                    style={{ width: `${25 * (index + 1)}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg hover-lift">
          <h3 className="text-2xl font-bold mb-6">Quick Tips</h3>
          <div className="space-y-4 stagger-animation">
            {[
              'Update your resume every 3-6 months',
              'Research companies before interviews',
              'Practice mock interviews regularly',
              'Network with industry professionals'
            ].map((tip, index) => (
              <div
                key={index}
                className="flex items-center p-3 bg-purple-50 rounded-lg"
              >
                <svg
                  className="w-6 h-6 text-purple-600 mr-3"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
                  />
                </svg>
                {tip}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Call to Action */}
      <div className="mt-16 text-center">
        <button className="bg-purple-600 text-white px-8 py-4 rounded-xl font-bold text-lg hover-lift">
          Schedule Career Consultation
        </button>
      </div>
    </div>
  );
}

export default CareerGuidance;
