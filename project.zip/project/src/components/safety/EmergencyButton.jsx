import React, { useState } from 'react';
import { ShieldExclamationIcon } from '@heroicons/react/24/solid';

function EmergencyButton() {
  const [isActive, setIsActive] = useState(false);

  const handleEmergency = () => {
    setIsActive(true);
    // In a real application, this would trigger emergency services
    setTimeout(() => {
      setIsActive(false);
    }, 3000);
  };

  return (
    <div className="fixed bottom-8 right-8">
      <button
        onClick={handleEmergency}
        className={`flex items-center space-x-2 px-6 py-3 rounded-full shadow-lg transition-all ${
          isActive 
            ? 'bg-red-600 animate-pulse' 
            : 'bg-red-500 hover:bg-red-600'
        } text-white font-bold`}
      >
        <ShieldExclamationIcon className="h-6 w-6" />
        <span>Emergency SOS</span>
      </button>
    </div>
  );
}

export default EmergencyButton;