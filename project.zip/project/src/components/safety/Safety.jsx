import React from 'react';
import { Routes, Route } from 'react-router-dom';
import EmergencyButton from './EmergencyButton';
import AbuseReporting from './AbuseReporting';
import LegalAid from './LegalAid';
import ResourceCenter from './ResourceCenter';

function Safety() {
  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Safety & Support Hub</h1>
      <EmergencyButton />
      <Routes>
        <Route index element={<ResourceCenter />} />
        <Route path="report" element={<AbuseReporting />} />
        <Route path="legal" element={<LegalAid />} />
      </Routes>
    </div>
  );
}

export default Safety;