import React from 'react';
import { Routes, Route } from 'react-router-dom';
import BudgetingTools from './BudgetingTools';
import InvestmentEducation from './InvestmentEducation';
import Crowdfunding from './Crowdfunding';

function Finance() {
  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Financial Management Hub</h1>
      <Routes>
        <Route index element={<BudgetingTools />} />
        <Route path="investment" element={<InvestmentEducation />} />
        <Route path="crowdfunding" element={<Crowdfunding />} />
      </Routes>
    </div>
  );
}

export default Finance;