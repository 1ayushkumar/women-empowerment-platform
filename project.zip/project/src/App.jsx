import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Features from './components/Features';
import LoginForm from './components/auth/LoginForm';
import RegisterForm from './components/auth/RegisterForm';
import Home from './components/home/Home';
import ProtectedRoute from './components/auth/ProtectedRoute';
import Education from './components/education/Education';
import Entrepreneurship from './components/entrepreneurship/Entrepreneurship';
import Employment from './components/employment/Employment';
import Health from './components/health/Health';
import Safety from './components/safety/Safety';
import Finance from './components/finance/Finance';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
        <Routes>
          {/* Public Routes */}
          <Route path="/" element={
            <>
              <Navbar />
              <main>
                <Hero />
                <Features />
              </main>
            </>
          } />
          <Route path="/login" element={
            <>
              <Navbar />
              <LoginForm />
            </>
          } />
          <Route path="/register" element={
            <>
              <Navbar />
              <RegisterForm />
            </>
          } />

          {/* Protected Routes */}
          <Route path="/home" element={
            <ProtectedRoute>
              <>
                <Navbar />
                <Home />
              </>
            </ProtectedRoute>
          } />
          <Route path="/education/*" element={
            <ProtectedRoute>
              <>
                <Navbar />
                <Education />
              </>
            </ProtectedRoute>
          } />
          <Route path="/entrepreneurship/*" element={
            <ProtectedRoute>
              <>
                <Navbar />
                <Entrepreneurship />
              </>
            </ProtectedRoute>
          } />
          <Route path="/employment/*" element={
            <ProtectedRoute>
              <>
                <Navbar />
                <Employment />
              </>
            </ProtectedRoute>
          } />
          <Route path="/health/*" element={
            <ProtectedRoute>
              <>
                <Navbar />
                <Health />
              </>
            </ProtectedRoute>
          } />
          <Route path="/safety/*" element={
            <ProtectedRoute>
              <>
                <Navbar />
                <Safety />
              </>
            </ProtectedRoute>
          } />
          <Route path="/finance/*" element={
            <ProtectedRoute>
              <>
                <Navbar />
                <Finance />
              </>
            </ProtectedRoute>
          } />
        </Routes>
      </div>
    </Router>
  );
}

export default App;